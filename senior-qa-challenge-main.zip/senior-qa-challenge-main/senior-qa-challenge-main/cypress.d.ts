declare namespace Cypress {
  interface Chainable {
    /**
     * Custom command to select DOM element by data-cy attribute.
     * @example cy.dataCy('greeting')
     */
    validateAPIRequests(apiUrl: string): boolean;
    mockData(): Chainable<Element>;
    waitForReq(): Chainable<Element>;
  }
}
