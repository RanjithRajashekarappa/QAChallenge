import React from "react";
import { UnitSystem } from "./units";

export const UnitSystemContext = React.createContext(UnitSystem.Metric);
