export enum UnitSystem {
  Imperial = "Imperial",
  Metric = "Metric",
}
