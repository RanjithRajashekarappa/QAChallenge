export { default } from "./FormattedTemperature";
