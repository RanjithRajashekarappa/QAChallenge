export { default as SettingsLocationsSelector } from "./SettingsLocationsSelector";
