export { default } from "./LocationCard";
