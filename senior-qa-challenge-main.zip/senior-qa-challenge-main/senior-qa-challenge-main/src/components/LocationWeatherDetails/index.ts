export { default } from "./LocationWeatherDetails";
