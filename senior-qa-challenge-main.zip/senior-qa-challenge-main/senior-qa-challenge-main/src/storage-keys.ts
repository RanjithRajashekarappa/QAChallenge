export const UNITS_STORAGE_KEY = "weather.units";
export const LOCATIONS_STORAGE_KEY = "weather.locations";
