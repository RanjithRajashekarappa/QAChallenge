import { mockLocation } from "../support/utils";
import { mockResponseMumbaiLocation } from "../support/mockResponse";
import { locators } from "../../cypress/support/locators";

describe("Tests for verifying UI of weather application", () => {
  beforeEach("UI Tests", () => {
    cy.visit(
      "http://localhost:3000/weather",
      mockLocation(59.911491, 10.757933)
    );
  });

  it("Verify that user can add/remove geographical locations", () => {
    cy.window()
      .then(function (p) {
        cy.stub(p, "prompt").returns("mumbai");
        cy.get(".mt-5 > a").click();
        cy.get(":nth-child(1) > :nth-child(3) > .button").click();
        cy.get(".has-text-centered > a").click();
      })
      .then(() => {
        cy.get(".column.is-one-quarter").then(($elements) => {
          const lastElement = $elements[$elements.length - 1];

          cy.wrap(lastElement)
            .find(locators.weatherCardLocation)
            .invoke("text")
            .should("eq", "mumbai");
        });
      });
  });

  it("Verify that user can switch units to Metric", () => {
    cy.get(".mt-5 > a")
      .click()
      .then(() => {
        cy.get(".buttons > :nth-child(1)")
          .click()
          .then(() => {
            cy.get(".has-text-centered > a")
              .click()
              .then(() => {
                cy.get(locators.weatherCardTemperature)
                  .invoke("text")
                  .should("includes", "C");
              });
          });
      });
  });

  it("Verify that user can switch units to Imperial", () => {
    cy.get(".mt-5 > a")
      .click()
      .then(() => {
        cy.get(".buttons > :nth-child(2)")
          .click()
          .then(() => {
            cy.get(".has-text-centered > a")
              .click()
              .then(() => {
                cy.get(locators.weatherCardTemperature)
                  .invoke("text")
                  .should("includes", "F");
              });
          });
      });
  });

  it("Verify that application can use current location", () => {
    cy.visit(
      "http://localhost:3000/weather",
      mockLocation(19.0785451, 72.878176)
    );
    cy.get(locators.weatherCardLocation)
      .invoke("text")
      .should("eq", "Konkan Dision");
  });
  it("Verify details on application by mocking the weather data returned", () => {
    cy.mockData();
    cy.window()
      .then(function (p) {
        cy.stub(p, "prompt").returns("delhi");
        cy.get(".mt-5 > a").click();
        cy.get(":nth-child(1) > :nth-child(3) > .button").click();
        cy.get(".has-text-centered > a").click();
      })
      .then(() => {
        cy.waitForReq().then(() => {
          cy.get(
            ':nth-child(1) > [data-testid="weather-card"] > .card > .card-content'
          )
            .click()
            .then(() => {
              cy.get(locators.highestExpectedTemperature)
                .invoke("text")
                .then((text) => {
                  const temperatureWithoutSymbol = text.match(/\d+/);
                  expect(
                    mockResponseMumbaiLocation.main.temp_max.toString()
                  ).to.include(temperatureWithoutSymbol[0]);
                });

              cy.get(locators.lowestExpectedTempewrature)
                .invoke("text")
                .then((text) => {
                  const temperatureWithoutSymbol = text.match(/\d+/);
                  expect(
                    mockResponseMumbaiLocation.main.temp_min.toString()
                  ).to.include(temperatureWithoutSymbol[0]);
                });
              cy.get(":nth-child(3) > .is-size-5")
                .invoke("text")
                .then((text) => {
                  const humidity = text.match(/\d+/);
                  expect(
                    mockResponseMumbaiLocation.main.humidity.toString()
                  ).to.include(humidity[0]);
                });

              cy.get(":nth-child(1) > .is-size-5")
                .invoke("text")
                .then((text) => {
                  const sunrise = text;

                  expect(
                    new Date(
                      mockResponseMumbaiLocation.sys.sunrise * 1000
                    ).toString()
                  ).to.include(sunrise);
                });
            });
        });
      });
  });
});
