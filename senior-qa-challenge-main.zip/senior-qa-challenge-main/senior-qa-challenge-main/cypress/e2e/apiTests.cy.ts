import coordinates from "../fixtures/locationCoordinates.json";

describe("API tests", () => {
  it("Validate weather API returns success response and fields that are used by application exist", () => {
    coordinates.forEach((coord) => {
      cy.validateAPIRequests(
        `https://api.openweathermap.org/data/2.5/weather?lat=${coord.lat}&lon=${coord.lat}&units=Metric&appid=eb8a70f875f4e4baabc1399cec36e4b6`
      );
    });
  });
});
