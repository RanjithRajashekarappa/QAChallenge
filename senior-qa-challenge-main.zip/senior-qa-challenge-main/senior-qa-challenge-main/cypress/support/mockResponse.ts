export const mockResponseMumbaiLocation = {
  coord: {
    lon: 72.8782,
    lat: 19.0785,
  },
  weather: [
    {
      id: 721,
      main: "Haze",
      description: "haze",
      icon: "50n",
    },
  ],
  base: "stations",
  main: {
    temp: 30.03,
    feels_like: 37.03,
    temp_min: 30.03,
    temp_max: 30.03,
    pressure: 1012,
    humidity: 84,
  },
  visibility: 2200,
  wind: {
    speed: 1.54,
    deg: 240,
  },
  clouds: {
    all: 100,
  },
  dt: 1698005898,
  sys: {
    type: 1,
    id: 9052,
    country: "IN",
    sunrise: 1698023094,
    sunset: 1698064836,
  },
  timezone: 19800,
  id: 8131499,
  name: "mumbai",
  cod: 200,
};
