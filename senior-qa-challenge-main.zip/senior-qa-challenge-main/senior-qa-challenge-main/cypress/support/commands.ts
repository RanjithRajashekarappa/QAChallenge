/// <reference types="cypress" />
import "chai-json-schema";
import { mockResponseMumbaiLocation } from "../support/mockResponse";

// ***********************************************
// This example commands.ts shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add('login', (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add('drag', { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add('dismiss', { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })
//
// declare global {
//   namespace Cypress {
//     interface Chainable {
//       login(email: string, password: string): Chainable<void>
//       drag(subject: string, options?: Partial<TypeOptions>): Chainable<Element>
//       dismiss(subject: string, options?: Partial<TypeOptions>): Chainable<Element>
//       visit(originalFn: CommandOriginalFn, url: string, options: Partial<VisitOptions>): Chainable<Element>
//     }
//   }
// }

Cypress.Commands.add("validateAPIRequests", (apiUrl) => {
  cy.request("GET", apiUrl).then((response) => {
    expect(response.status).to.eq(200);

    expect(response.body.main.feels_like).to.exist;
    expect(response.body.main.humidity).to.exist;
    expect(response.body.main.pressure).to.exist;
    expect(response.body.main.temp).to.exist;
    expect(response.body.main.temp_max).to.exist;
    expect(response.body.main.temp_min).to.exist;
    expect(response.body.sys.sunrise).to.exist;
    expect(response.body.sys.sunset).to.exist;
    expect(response.body.visibility).to.exist;
    expect(response.body.weather[0].main).to.exist;
  });
});

Cypress.Commands.add("mockData", () => {
  const response = mockResponseMumbaiLocation;
  cy.intercept("GET", "https://api.openweathermap.org/data/**", (req) => {
    req.reply(response);
  }).as("InterceptedRequest");
});

Cypress.Commands.add("waitForReq", () => {
  cy.wait("@InterceptedRequest").its("response.statusCode").should("eq", 200);
});
