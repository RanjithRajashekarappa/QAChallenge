export const locators: any = {
  weatherCardTemperature: '[data-testid="weather-card-temperature"]',
  weatherCardLocation: '[data-testid="weather-card-location"]',
  highestExpectedTemperature: '[aria-label="Highest expected temperature"]',
  lowestExpectedTempewrature: '[aria-label="Lowest expected temperature"]',
};
