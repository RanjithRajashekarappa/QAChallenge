import "./commands";
import "cypress-xpath";
import "chai-json-schema";

import addContext from "mochawesome/addContext";

Cypress.on("test:after:run", (test, runnable) => {
  if (test.state === "failed") {
    const screenshot = `${Cypress.spec.name}/${runnable.parent.title} -- ${test.title} (failed).png`;
    //const screenshot = `images/test.png`
    addContext({ test }, screenshot);
  }
});
